﻿using System;
using System.Collections;

namespace DevOpsBoise
{
  public class Bingo
  {
    private static Random r = new Random();

    public string GetBuzzword()
    {
      ArrayList buzzword = new ArrayList();
      buzzword.Add("Netflix");
      buzzword.Add("Firefighting");
      buzzword.Add("Puppet");
      buzzword.Add("Flow");
      buzzword.Add("Dening");
      buzzword.Add("ITIL");
      buzzword.Add("Community");
      buzzword.Add("Open Source");
      buzzword.Add("Continuous Delivery");
      buzzword.Add("Infrastructure as Code");
      buzzword.Add("Speed");
      buzzword.Add("Chef");
      buzzword.Add("Facebook");
      buzzword.Add("Code");
      buzzword.Add("Collaboration");
      buzzword.Add("Automation");
      buzzword.Add("Adapt");
      buzzword.Add("Awesome");
      buzzword.Add("Kanban");
      buzzword.Add("Etsy");
      buzzword.Add("Agile");
      buzzword.Add("Revolution");
      buzzword.Add("Culture");
      buzzword.Add("Blueprint");
      buzzword.Add("Journey");
      buzzword.Add("Red team");
      buzzword.Add("Alerts");
      buzzword.Add("API");
      buzzword.Add("Microservices");
      buzzword.Add("Continous Integration");
      buzzword.Add("Docker");
      buzzword.Add("Containers");
      buzzword.Add("Kaizen");
      buzzword.Add("Pipeline");
      buzzword.Add("Machine learning");
      buzzword.Add("Enterprise");

      // Rturn a random buzzword

      int index = r.Next(0, buzzword.Count); //for ints
      return buzzword[index].ToString();
    }
  }
}
