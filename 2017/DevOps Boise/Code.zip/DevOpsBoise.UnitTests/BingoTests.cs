﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DevOpsBoise
{
  [TestClass]
  public class BingoTests
  {
    [TestMethod]
    public void One_Buzzword_NotEmpty()
    {
      Bingo bingo = new Bingo();
      string buzzword = bingo.GetBuzzword();
      if (buzzword == "") Assert.Fail();
    }

    [TestMethod]
    public void All_100_Buzzwords_NotEmpty()
    {
      Bingo bingo = new Bingo();
      for (int i = 0; i < 100; i++)
      {
        string buzzword = bingo.GetBuzzword();
        if (buzzword == "") Assert.Fail();
      }
    }

    [TestMethod]
    public void All_5000_Buzzwords_NotEmpty()
    {
      Bingo bingo = new Bingo();
      for (int i = 0; i < 5000; i++)
      {
        string buzzword = bingo.GetBuzzword();
        if (buzzword == "") Assert.Fail();
      }
    }

    [TestMethod]
    public void Buzzwords_Are_Truly_Random()
    {
      Bingo bingo = new Bingo();
      string lastBuzzword = "";
      int duplicates = 0;
      for (int i = 0; i < 1000; i++)
      {
        string buzzword = bingo.GetBuzzword();
        if (buzzword == lastBuzzword)
        {
          duplicates++;
        }
        lastBuzzword = buzzword;
      }
      if (duplicates > 50) Assert.Fail(string.Format("Too many duplicates: {0}",duplicates));
    }
  }
}
