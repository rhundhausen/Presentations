﻿using System;
using Microsoft.ApplicationInsights;
using System.Web.UI;

namespace DevOpsBoise.Web
{
  public partial class _Default : Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
      // lblBuzzword.Text = "TBD";
      Bingo bingo = new Bingo();
      lblBuzzword.Text = bingo.GetBuzzword();

      TelemetryClient telemetry = new TelemetryClient();
      telemetry.TrackEvent("Buzzword_PageLoad");
    }

    protected void btnNext_Click(object sender, EventArgs e)
    {
      Bingo bingo = new Bingo();
      lblBuzzword.Text = bingo.GetBuzzword();
      TelemetryClient telemetry = new TelemetryClient();
      telemetry.TrackEvent("Buzzword_NextButton");
    }
  }
}