﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SlowUnitTests
{
  [TestClass]
  [TestCategory("Risky")]
  public class UnitTests
  {

    [TestMethod]
    public void SlowUnitTestA1()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestA2()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestA3()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestA4()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestA5()
    {
      System.Threading.Thread.Sleep(1000);
    }
  }
}
