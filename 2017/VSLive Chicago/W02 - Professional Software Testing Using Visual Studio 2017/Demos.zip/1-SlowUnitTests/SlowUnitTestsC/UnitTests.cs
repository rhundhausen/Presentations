﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SlowUnitTests
{
  [TestClass]
  public class UnitTests
  {

    [TestMethod]
    public void SlowUnitTestC1()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC2()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC3()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC4()
    {
      System.Threading.Thread.Sleep(1000);
    }

    [TestMethod]
    public void SlowUnitTestC5()
    {
      System.Threading.Thread.Sleep(1000);
    }
  }
}
