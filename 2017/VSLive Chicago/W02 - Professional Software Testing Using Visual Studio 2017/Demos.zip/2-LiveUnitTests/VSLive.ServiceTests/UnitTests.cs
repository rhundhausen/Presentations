﻿using VSLive.Service;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace VSLive.Service
{
  [TestClass]
  public class ConferenceTests
  {
    Conference service;

    public ConferenceTests()
    {
      service = new Conference();
    }

    [TestMethod]
    public void Add_Test()
    {
      service.Add();
    }

    [TestMethod]
    public void Find_Test()
    {
      int actual = service.Find();
      Assert.AreEqual(42, actual);
    }

    [TestMethod]
    public void List_Test()
    {
      service.List ();
    }

    [TestMethod]
    public void Remove_Test()
    {
      service.Remove();
    }
  }

  [TestClass]
  public class SessionTests
  {
    Session service;

    public SessionTests()
    {
      service = new Session();
    }

    [TestMethod]
    public void Add_Test()
    {
      service.Add();
    }

    [TestMethod]
    public void Find_Test()
    {
      int actual = service.Find();
      Assert.AreEqual(42, actual);
    }

    [TestMethod]
    public void List_Test()
    {
      service.List();
    }

    [TestMethod]
    public void Remove_Test()
    {
      service.Remove();
    }
  }

  [TestClass]
  public class SpeakerTests
  {
    Speaker service;

    public SpeakerTests()
    {
      service = new Speaker();
    }

    [TestMethod]
    public void Add_Test()
    {
      service.Add();
    }

    [TestMethod]
    public void Find_Test()
    {
      int actual = service.Find();
      Assert.AreEqual(42, actual);
    }

    [TestMethod]
    public void List_Test()
    {
      service.List();
    }

    [TestMethod]
    public void Remove_Test()
    {
      service.Remove();
    }
  }
}
