﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace VSLive.Session.UnitTests
{
  [TestClass]
  public class SessionTests
  {
    [TestMethod]
    public void Add_Test()
    {
      System.Threading.Thread.Sleep(500);
    }
    [TestMethod]
    public void Remove_Test()
    {
      System.Threading.Thread.Sleep(500);
    }
    [TestMethod]
    public void Find_Test()
    {
      System.Threading.Thread.Sleep(500);
    }
    [TestMethod]
    public void List_Test()
    {
      System.Threading.Thread.Sleep(500);
    }
  }
}
