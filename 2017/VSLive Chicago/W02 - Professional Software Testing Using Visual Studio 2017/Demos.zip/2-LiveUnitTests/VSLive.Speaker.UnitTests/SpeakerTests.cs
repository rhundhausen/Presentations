﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VSLive.Service;

namespace VSLive.Speaker
{
  [TestClass]
  public class SpeakerTests
  {
    [TestMethod]
    public void Add_Test()
    {
      VSLive.Service.Speaker speaker = new Service.Speaker();
      speaker.Add();
    }
    [TestMethod]
    public void Remove_Test()
    {
      System.Threading.Thread.Sleep(500);
    }
    [TestMethod]
    public void Find_Test()
    {
      System.Threading.Thread.Sleep(500);
    }
    [TestMethod]
    public void List_Test()
    {
      System.Threading.Thread.Sleep(500);
    }
  }
}
