﻿using System.Threading;

namespace VSLive.Service
{
  public class Speaker
  {
    public void Add() { Thread.Sleep(250); }
    public void Remove() { Thread.Sleep(250); }
    public int Find() { Thread.Sleep(250); return 4; }
    public void List() { Thread.Sleep(250); }
  }
}