﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoolTest
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.Out.WriteLine("I am STDOUT");
      if (args.Length != 1)
      {
       Console.Error.WriteLine("I am STDERR");
       Environment.Exit(-1);
      }
      Environment.Exit(0);
    }
  }
}
