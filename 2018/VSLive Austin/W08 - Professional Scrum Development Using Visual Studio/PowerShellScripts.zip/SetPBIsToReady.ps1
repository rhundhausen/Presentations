﻿function Main
{
  cls
  $VstsAccount = "https://<your account>.visualstudio.com"
  $VstsToken = "<your personal access token>"
  $VstsTeamProject = "<your team project>"

  # Don't change anything below here

  $basicAuth = ("{0}:{1}" -f "",$VstsToken)
  $basicAuth = [System.Text.Encoding]::UTF8.GetBytes($basicAuth)
  $basicAuth = [System.Convert]::ToBase64String($basicAuth)
  $headers = @{Authorization=("Basic {0}" -f $basicAuth)}

  Write-Host
  Write-Host "  Setting PBIs to Ready ..."
  SetPBIsToReady
}

function SetPBIsToReady
{
  $resource = $VstsAccount + "/" + $VstsTeamProject + '/_apis/wit/wiql/?api-version=3.0'
  $json = '{ "query": "Select [System.ID] FROM WorkItems Where [System.WorkItemType] = ' + "'Product Backlog Item'" + ' AND [System.TeamProject] = ' + "'" + $VstsTeamProject + "'" + '" }'
  try {
    $response = Invoke-RestMethod -Uri $resource -headers $headers -Method Post -Body $json -ContentType 'application/json'
    foreach ($workItem in $response.workItems) {
      $id = $workItem.id
      $resource = $VstsAccount + '/_apis/wit/workitems/' + $id + '?api-version=3.0'
      $json = '[{"op": "add","path": "/fields/System.State","value": "Ready"}]'
      try {
        $response2 = Invoke-RestMethod -Uri $resource -headers $headers -Method Patch -Body $json -ContentType 'application/json-patch+json'
      }
      catch {
        echo $_.Exception|format-list -force
      }
    }
  }
  catch {
    echo $_.Exception|format-list -force
  }
}

Main