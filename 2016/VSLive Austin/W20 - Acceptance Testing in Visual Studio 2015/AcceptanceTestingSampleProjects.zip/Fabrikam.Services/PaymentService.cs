﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fabrikam.Services
{
  public class PaymentService
  {
    public bool SendPayment()
    {
      return true;
    }

    public bool ReceivePayment()
    {
      return true;
    }

    public bool ProcessPayment()
    {
      return true;
    }
  }
}
