﻿using System;
using System.Collections.Generic;

namespace Fabrikam.Services
{
  public class Tweet
  {
    public string text { get; set; }
    public string user { get; set; }
    public string created { get; set; }
    public int retweets { get; set; }
    public int favorites { get; set; }
    public string lang { get; set; }
  }

  public class TwitterService
  {

    private List<Tweet> GetTweets(int count)
    {
      var tweets = new List<Tweet>(count);

      for (int i = 0; i < count; i++)
      {
        tweets.Add(new Tweet { text = "Fabrikam Fiber and its products are awesome", user = "@VSLive" });
      }
      return tweets;
    }

    public List<Tweet> GetAllTweets()
    {
      return GetTweets(21);
    }

    public List<Tweet> GetLast10Tweets()
    {
      return GetTweets(100);
    }

    public List<Tweet> GetLast10CleanTweets()
    {
      return GetTweets(10);
    }

    public List<Tweet> GetProfaneTweets()
    {
      return GetTweets(0);
    }

  }
}
