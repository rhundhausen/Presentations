﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fabrikam.Services
{
  public class Scheduling
  {
    public bool ScheduleCall()
    {
      return true;
    }

    public bool ScheduleVisit()
    {
      return true;
    }

    public bool ScheduleFollowUp()
    {
      return true;
    }

  }
}
