﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Fabrikam.Services;

namespace Fabrikam.UnitTests
{
  [TestClass]
  public class PaymentTests
  {
    [TestMethod]
    public void Payment_ProcessExactPayment()
    {
    }

    [TestMethod]
    public void Payment_ProcessOverPayment()
    {
    }

    [TestMethod]
    public void Payment_ProcessPartialPayment()
    {
    }

    [TestMethod]
    public void Payment_ReceiveCompletePayment()
    {
    }

    [TestMethod]
    public void Payment_ReceivePartialPayment()
    {
    }

    [TestMethod]
    public void Payment_ReceiveOverPayment()
    {
    }

  }
}
