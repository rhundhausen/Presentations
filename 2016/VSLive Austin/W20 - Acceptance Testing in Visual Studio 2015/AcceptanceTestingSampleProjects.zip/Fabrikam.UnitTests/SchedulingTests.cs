﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Fabrikam.Services;

namespace Fabrikam.UnitTests
{
  [TestClass]
  public class ScheduleTests
  {
    [TestMethod]
    public void Schedule_ScheduleCall()
    {
    }

    [TestMethod]
    public void Schedule_ScheduleAfterHoursCall()
    {
    }

    [TestMethod]
    public void Schedule_ScheduleVisit()
    {
    }

    [TestMethod]
    public void Schedule_ScheduleMultipleVisits()
    {
    }

    [TestMethod]
    public void Schedule_ScheduleAfterHoursVisit()
    {
    }

    [TestMethod]
    public void Schedule_RescheduleVisit()
    {
    }

    [TestMethod]
    public void Schedule_RescheduleCall()
    {
    }

    [TestMethod]
    public void Schedule_RescheduleFollowUp()
    {
    }

    [TestMethod]
    public void Schedule_ScheduleFollowUp()
    {
    }

    [TestMethod]
    public void Schedule_ScheduleMultipleFollowUps()
    {
    }
  }
}
