﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Fabrikam.Services;
using System.Collections.Generic;

namespace Fabrikam.UnitTests
{
  [TestClass]
  public class TwitterTests
  {
    [TestMethod]
    public void Twitter_10TweetsOnly()
    {
      // arrange
      TwitterService service = new TwitterService();

      // act
      List<Tweet> tweets = service.GetLast10Tweets();

      // assert
      Assert.AreEqual(10,tweets.Count);
    }

    [TestMethod]
    public void Twitter_NoProfaneTweets()
    {
      TwitterService service = new TwitterService();

      List<Tweet> tweets = service.GetProfaneTweets();

      Assert.AreEqual(0, tweets.Count);
    }

    #region "Ordered unit tests"

    [TestCategory("Ordered"), TestCategory("Richard"), TestMethod()]
    public void Twitter_CreateTestTweet()
    {
      // Create tweet via Twitter API

      System.Threading.Thread.Sleep(3000);

      // check time
    }

    [TestCategory("Ordered"), TestMethod()]
    public void Twitter_TweetAppearedWithin60Seconds()
    {
      // Check page
    }

    [TestCategory("Ordered"), TestMethod()]
    public void Twitter_DeleteTestTweet()
    {
      // Create tweet via Twitter API

      System.Threading.Thread.Sleep(1000);

      // check time
    }

    [TestCategory("Ordered"), TestMethod()]
    public void Twitter_TweetDisappearedWithin60Seconds()
    {
      // Check page
    }
    #endregion

  }
}
